// =========================================================
// 1. FUNCIONALIDADE DO BOTÃO DE VOLTAR (Redirecionamento para Login)
// =========================================================

// Pega o  botão "Voltar" usando o ID  do HTML
const backButton = document.getElementById('back-to-login-btn'); 

// Adiciona um 'ouvinte de evento' de clique
if (backButton) {
    backButton.addEventListener('click', function() {
        //  Redireciona o usuário DIRETAMENTE para a página de login
        window.location.href = 'login.html';
    });
}


// =========================================================
// 2. MOSTRAR/ESCONDER SENHA
// =========================================================

// Adiciona a funcionalidade de clique a todos os ícones de olho
document.querySelectorAll('.toggle-password').forEach(icon => {
    icon.addEventListener('click', function() {
        const targetId = this.getAttribute('data-target');
        const passwordInput = document.getElementById(targetId);

        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            this.classList.remove('fa-eye');
            this.classList.add('fa-eye-slash'); // Mostra o ícone de olho cortado
        } else {
            passwordInput.type = 'password';
            this.classList.remove('fa-eye-slash');
            this.classList.add('fa-eye'); // Mostra o ícone de olho normal
        }
    });
});


// =========================================================
// 3. LIMPAR E VALIDAR FORMULÁRIO
// =========================================================

// Ação do botão "Limpar"
document.getElementById('clear-btn').addEventListener('click', function() {
    document.getElementById('registration-form').reset();
});

// Validação simples ao tentar registrar
document.getElementById('registration-form').addEventListener('submit', function(event) {
    // Previne o envio padrão (para rodar a validação JS)
    event.preventDefault();

    const email = document.getElementById('email').value;
    const confirmEmail = document.getElementById('confirm-email').value;
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmar-senha').value;

    let isValid = true;

    // A. Validar E-mail
    if (email !== confirmEmail) {
        alert('Os e-mails não coincidem.');
        document.getElementById('email').focus();
        isValid = false;
    }

    // B. Validar Senha
    else if (senha !== confirmarSenha) {
        alert('As senhas não coincidem.');
        document.getElementById('senha').focus();
        isValid = false;
    }
    
    // C. Validar preenchimento mínimo
    else if (email === '' || senha === '') {
        alert('Por favor, preencha todos os campos obrigatórios (E-mail e Senha).');
        isValid = false;
    }

    if (isValid) {
        // Se a validação passar, simula o envio de dados 
        alert('Registro bem-sucedido!');
    }
});