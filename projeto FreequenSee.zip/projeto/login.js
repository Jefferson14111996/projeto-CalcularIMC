// Funcionalidade de Toggle da Senha (Reaproveitada do script.js)
document.querySelectorAll('.toggle-password').forEach(icon => {
    icon.addEventListener('click', function() {
        const targetId = this.getAttribute('data-target');
        const passwordInput = document.getElementById(targetId);

        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            this.classList.remove('fa-eye');
            this.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            this.classList.remove('fa-eye-slash');
            this.classList.add('fa-eye');
        }
    });
});

// Funcionalidade de Login
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('login-email').value;
    const senha = document.getElementById('login-senha').value;

    if (email === '' || senha === '') {
        alert('Por favor, preencha o E-mail e a Senha.');
        return;
    }

    // SIMULAÇÃO: Em um projeto real, aqui você faria uma requisição POST ao servidor
    // para autenticar o usuário.
    alert(`Tentativa de Login com E-mail: ${email}`);
    // Se o login fosse bem-sucedido, você redirecionaria o usuário:
    // window.location.href = '/dashboard.html'; 
});